setwd("C:\\Users\\Induwara Chandupa\\Desktop\\IT24102492")


#Exercise
#1

punif(25,min =0,max=40,lower.tail = TRUE)-punif(10,min =0,max=40,lower.tail = TRUE)

#2

pexp(2,rate=0.33,lower.tail=TRUE)

#3
#i.

1-pnorm(130,mean =100,sd=15,lower.tail=TRUE)

#ii.

qnorm(0.95,mean =100,sd=15,lower.tail=TRUE)




